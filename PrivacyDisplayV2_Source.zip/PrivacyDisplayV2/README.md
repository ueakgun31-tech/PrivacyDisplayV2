# Privacy Display V2

Android Studio project with a GitHub Actions workflow that builds a debug APK in the cloud. No PC is required if you upload this project to a GitHub repository from your phone.

## Build APK in GitHub
1. Create a new **public or private** repository named `PrivacyDisplayV2` on GitHub.
2. Upload the contents of this folder (not the outer ZIP file) to the repository root. Make sure `.github/workflows/build-apk.yml` is included.
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. Select **Build Privacy Display APK**, tap **Run workflow**, and wait for the run to finish successfully.
5. Open the completed workflow run and download the `PrivacyDisplayV2-debug-apk` artifact. GitHub may deliver it as a ZIP; extract it on the phone to get `app-debug.apk`.
6. Install the APK and grant “Display over other apps” permission when prompted by the app.

## Limitations
This is a software dimming overlay, not true directional privacy glass. It dims the screen for everyone and cannot selectively hide content from side viewers. This is a debug APK, not a Play Store release build. The app uses an overlay permission and a persistent notification while active. Xiaomi/MIUI battery management can affect background behavior.

package com.example.privacydisplayv2;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class DimOverlayService extends Service {
    static final String ON = "com.example.privacydisplayv2.ON";
    static final String OFF = "com.example.privacydisplayv2.OFF";
    static final String EXTRA_PERCENT = "percent";
    private static final String CHANNEL = "privacy_display";
    private static final int NOTIFICATION_ID = 2026;
    private WindowManager wm;
    private View overlay;

    @Override public void onCreate() { super.onCreate(); wm = (WindowManager)getSystemService(WINDOW_SERVICE); makeChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ON : intent.getAction();
        if (OFF.equals(action)) { removeOverlay(); stopForeground(true); stopSelf(); return START_NOT_STICKY; }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        int percent = intent == null ? 45 : intent.getIntExtra(EXTRA_PERCENT, 45);
        percent = Math.max(0, Math.min(85, percent));
        startForeground(NOTIFICATION_ID, notification());
        showOverlay(percent);
        return START_NOT_STICKY;
    }

    private void showOverlay(int percent) {
        removeOverlay(); if (percent == 0) return;
        FrameLayout view = new FrameLayout(this); view.setBackgroundColor(Color.BLACK); view.setAlpha(percent / 100f);
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        try { wm.addView(view, p); overlay = view; }
        catch (Exception e) { overlay = null; stopForeground(true); stopSelf(); }
    }
    private void removeOverlay() { if (overlay != null) { try { wm.removeView(overlay); } catch (Exception ignored) {} overlay = null; } }

    private Notification notification() {
        Intent off = new Intent(this, DimOverlayService.class).setAction(OFF);
        int immutable = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        PendingIntent offPending = PendingIntent.getService(this, 1, off, PendingIntent.FLAG_UPDATE_CURRENT | immutable);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 2, open, PendingIntent.FLAG_UPDATE_CURRENT | immutable);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("Privacy Display açık")
            .setContentText("Karartmayı kapatmak için bildirimi kullan.").setContentIntent(openPending).setOngoing(true)
            .addAction(new Notification.Action.Builder(null, "Kapat", offPending).build());
        return b.build();
    }
    private void makeChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Privacy Display", NotificationManager.IMPORTANCE_LOW);
            NotificationManager m = getSystemService(NotificationManager.class); if (m != null) m.createNotificationChannel(c);
        }
    }
    @Override public void onDestroy() { removeOverlay(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}

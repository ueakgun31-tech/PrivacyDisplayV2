package com.example.privacydisplayv2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private SeekBar slider;
    private TextView valueText;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(22));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF3F4F6);

        TextView title = new TextView(this);
        title.setText("Privacy Display V2"); title.setTextSize(26); title.setTextColor(0xFF111827);
        title.setGravity(Gravity.CENTER); root.addView(title, params());

        TextView info = new TextView(this);
        info.setText("Manuel ekran karartma\n\nBu uygulama gerçek görüş açısı gizliliği sağlamaz. Ekranı herkes için karartır.");
        info.setTextSize(16); info.setTextColor(0xFF374151); info.setGravity(Gravity.CENTER);
        info.setPadding(0, dp(18), 0, dp(18)); root.addView(info, params());

        Button permission = new Button(this); permission.setText("Ekran üstünde gösterme izni ver");
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            } else Toast.makeText(this, "İzin zaten verilmiş.", Toast.LENGTH_SHORT).show();
        }); root.addView(permission, params());

        valueText = new TextView(this); valueText.setTextColor(0xFF111827); valueText.setTextSize(16);
        valueText.setPadding(0, dp(20), 0, dp(4)); root.addView(valueText, params());
        slider = new SeekBar(this); slider.setMax(85); slider.setProgress(45); updateLabel(45);
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean user) { updateLabel(p); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        }); root.addView(slider, params());

        Button on = new Button(this); on.setText("Karartmayı aç");
        on.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Önce ekran üstü iznini ver.", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                return;
            }
            Intent i = new Intent(this, DimOverlayService.class).setAction(DimOverlayService.ON);
            i.putExtra(DimOverlayService.EXTRA_PERCENT, slider.getProgress());
            startService(i);
        }); root.addView(on, params());

        Button off = new Button(this); off.setText("Karartmayı kapat");
        off.setOnClickListener(v -> startService(new Intent(this, DimOverlayService.class).setAction(DimOverlayService.OFF)));
        root.addView(off, params());

        TextView warning = new TextView(this);
        warning.setText("Not: Siyah katman yanlardan bakan kişiye özel gizlilik sağlamaz. Xiaomi/MIUI güç yönetimi çalışma şeklini etkileyebilir.");
        warning.setTextSize(13); warning.setTextColor(0xFF4B5563); warning.setPadding(0, dp(18), 0, 0); root.addView(warning, params());
        setContentView(root);
    }
    private void updateLabel(int p) { valueText.setText("Karartma: " + p + "%"); }
    private LinearLayout.LayoutParams params() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}
